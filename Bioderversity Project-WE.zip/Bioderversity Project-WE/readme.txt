�Completed Code in the Learning Environment�


(Reason � I am currently based on an island in PNG where internet service is slow and expensive. Downloads takes ages. Could not download clipart for the presentation.)

W.Ebofin
